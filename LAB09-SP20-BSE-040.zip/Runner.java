public class Runner
{
        public static void main(String[] args) {
            
            PhdStudent s1=new PhdStudent();
            GradeStudent s2=new GradeStudent();
            
            s1.takeExam();
            s2.takeExam();
        }
}