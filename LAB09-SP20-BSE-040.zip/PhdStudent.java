class PhdStudent extends Student{
    
    @Override
    public void takeExam(){
        System.out.println("Giving Final Defense Presentation!");
    }
}

