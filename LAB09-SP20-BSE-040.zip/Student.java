abstract class Student{
    
    public void takeExam(){
        System.out.println("Taking exam!");
    }
}