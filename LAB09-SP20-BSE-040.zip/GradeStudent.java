class GradeStudent extends Student{
    
    @Override
    public void takeExam(){
        System.out.println("Giving Written paper!");
    }
}

